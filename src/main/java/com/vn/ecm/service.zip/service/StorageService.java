package com.vn.ecm.service;

public interface StorageService {

    String getProviderName();

    //upload
    //download
    //delete
    //getList
}
